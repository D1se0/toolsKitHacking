VERSION = '4.7.0'


def version() -> str:
    return VERSION
