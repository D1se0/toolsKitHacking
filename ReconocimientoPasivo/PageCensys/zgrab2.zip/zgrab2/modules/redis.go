package modules

import "github.com/zmap/zgrab2/modules/redis"

func init() {
	redis.RegisterModule()
}
