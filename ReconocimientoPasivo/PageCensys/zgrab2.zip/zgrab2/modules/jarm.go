package modules

import "github.com/zmap/zgrab2/modules/jarm"

func init() {
	jarm.RegisterModule()
}
