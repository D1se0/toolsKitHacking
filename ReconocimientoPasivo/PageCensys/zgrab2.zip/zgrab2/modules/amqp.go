package modules

import "github.com/zmap/zgrab2/modules/amqp091"

func init() {
	amqp091.RegisterModule()
}
