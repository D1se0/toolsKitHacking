package modules

import "github.com/zmap/zgrab2/modules/pop3"

func init() {
	pop3.RegisterModule()
}
