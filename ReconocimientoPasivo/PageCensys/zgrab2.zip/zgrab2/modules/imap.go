package modules

import "github.com/zmap/zgrab2/modules/imap"

func init() {
	imap.RegisterModule()
}
