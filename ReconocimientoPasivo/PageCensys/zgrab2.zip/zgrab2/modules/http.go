package modules

import "github.com/zmap/zgrab2/modules/http"

func init() {
	http.RegisterModule()
}
