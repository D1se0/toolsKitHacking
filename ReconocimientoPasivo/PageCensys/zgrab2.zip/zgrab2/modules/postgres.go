package modules

import "github.com/zmap/zgrab2/modules/postgres"

func init() {
	postgres.RegisterModule()
}
