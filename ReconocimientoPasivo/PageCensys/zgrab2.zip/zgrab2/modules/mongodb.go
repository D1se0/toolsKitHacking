package modules

import "github.com/zmap/zgrab2/modules/mongodb"

func init() {
	mongodb.RegisterModule()
}
