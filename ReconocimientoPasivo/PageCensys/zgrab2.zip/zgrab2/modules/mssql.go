package modules

import "github.com/zmap/zgrab2/modules/mssql"

func init() {
	mssql.RegisterModule()
}
