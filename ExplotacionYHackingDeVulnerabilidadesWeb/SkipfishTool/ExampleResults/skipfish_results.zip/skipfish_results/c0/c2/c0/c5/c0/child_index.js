var child = [
  { 'dupe': false, 'type': 64, 'name': 'pagename=/var/www/html/mutillidae/src/home.php', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.5.177/mutillidae/src/includes/pop-up-help-context-generator.php?pagename=/var/www/html/mutillidae/src/home.php', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 }
];
