var issue = [
  { 'severity': 1, 'type': 20301, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 464, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'dir': 'i0' },
  { 'severity': 0, 'type': 10804, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 464, 'decl_mime': 'text/html', 'sniff_mime': 'application/xhtml+xml', 'cset': 'UTF-8', 'dir': 'i1' }
];
