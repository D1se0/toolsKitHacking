var child = [
  { 'dupe': false, 'type': 32, 'name': 'hints-menu.js', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.5.177/mutillidae/src/javascript/hints/hints-menu.js', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 }
];
