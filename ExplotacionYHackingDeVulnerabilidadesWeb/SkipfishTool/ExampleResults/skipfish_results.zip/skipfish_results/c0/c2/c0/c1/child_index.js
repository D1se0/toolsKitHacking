var child = [
  { 'dupe': false, 'type': 4, 'name': 'openldap', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.5.177/mutillidae/src/configuration/openldap/', 'fetched': true, 'code': 404, 'len': 275, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'iso-8859-1', 'missing': true, 'csens': false, 'child_cnt': 1, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xf6476f5a }
];
