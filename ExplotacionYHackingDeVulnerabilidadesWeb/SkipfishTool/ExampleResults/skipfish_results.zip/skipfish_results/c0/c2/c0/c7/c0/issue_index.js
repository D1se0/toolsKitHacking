var issue = [
  { 'severity': 3, 'type': 40401, 'sid': '0', 'extra': 'Delimited database dump', 'fetched': true, 'code': 200, 'len': 929, 'decl_mime': 'text/plain', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i0' },
  { 'severity': 0, 'type': 10803, 'sid': '0', 'extra': '', 'fetched': true, 'code': 200, 'len': 929, 'decl_mime': 'text/plain', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i1' },
  { 'severity': 0, 'type': 10802, 'sid': '0', 'extra': 'text/plain', 'fetched': true, 'code': 200, 'len': 929, 'decl_mime': 'text/plain', 'sniff_mime': 'text/plain', 'cset': '[none]', 'dir': 'i2' }
];
