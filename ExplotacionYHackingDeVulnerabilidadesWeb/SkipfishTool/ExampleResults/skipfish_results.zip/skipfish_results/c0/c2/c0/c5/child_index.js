var child = [
  { 'dupe': false, 'type': 8, 'name': 'pop-up-help-context-generator.php', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.5.177/mutillidae/src/includes/pop-up-help-context-generator.php', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 1, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 }
];
