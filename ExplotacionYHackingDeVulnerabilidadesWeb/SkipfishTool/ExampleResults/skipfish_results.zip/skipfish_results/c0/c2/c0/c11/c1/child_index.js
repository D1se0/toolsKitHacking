var child = [
  { 'dupe': false, 'type': 4, 'name': 'global-styles.css', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.5.177/mutillidae/src/hints-page-wrapper.php/styles/global-styles.css/', 'fetched': true, 'code': 200, 'len': 464, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0xfffbffff }
];
