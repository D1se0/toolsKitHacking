var issue = [
  { 'severity': 0, 'type': 10204, 'sid': '0', 'extra': 'X-XSS-Protection', 'fetched': true, 'code': 200, 'len': 5862, 'decl_mime': 'text/html', 'sniff_mime': '[none]', 'cset': 'UTF-8', 'dir': 'i0' }
];
