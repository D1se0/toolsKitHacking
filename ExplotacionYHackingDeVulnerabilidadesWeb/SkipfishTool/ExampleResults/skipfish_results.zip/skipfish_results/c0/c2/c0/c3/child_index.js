var child = [
  { 'dupe': false, 'type': 32, 'name': 'mutillidae-installation-on-xampp-win7.pdf', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.5.177/mutillidae/src/documentation/mutillidae-installation-on-xampp-win7.pdf', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 32, 'name': 'mutillidae-test-scripts.txt', 'dir': 'c1', 'linked': 2, 'url': 'http://192.168.5.177/mutillidae/src/documentation/mutillidae-test-scripts.txt', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 }
];
