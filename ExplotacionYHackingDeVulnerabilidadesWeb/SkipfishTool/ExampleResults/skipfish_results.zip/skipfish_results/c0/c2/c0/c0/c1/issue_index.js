var issue = [
  { 'severity': 0, 'type': 10801, 'sid': '0', 'extra': 'text/plain', 'fetched': true, 'code': 200, 'len': 1, 'decl_mime': 'text/html', 'sniff_mime': 'text/plain', 'cset': 'UTF-8', 'dir': 'i0' }
];
