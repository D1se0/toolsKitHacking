var child = [
  { 'dupe': false, 'type': 32, 'name': 'soap-services.html', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.5.177/mutillidae/src/webservices/soap/docs/soap-services.html', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 }
];
