var child = [
  { 'dupe': false, 'type': 4, 'name': 'ddsmoothmenu', 'dir': 'c0', 'linked': 2, 'url': 'http://192.168.5.177/mutillidae/src/styles/ddsmoothmenu/', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 1, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 4, 'name': 'gritter', 'dir': 'c1', 'linked': 2, 'url': 'http://192.168.5.177/mutillidae/src/styles/gritter/', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 1, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 },
  { 'dupe': false, 'type': 32, 'name': 'global-styles.css', 'dir': 'c2', 'linked': 2, 'url': 'http://192.168.5.177/mutillidae/src/styles/global-styles.css', 'fetched': false, 'error': 'Content not fetched', 'missing': false, 'csens': false, 'child_cnt': 0, 'issue_cnt': [ 0, 0, 0, 0, 0 ], 'sig': 0x0 }
];
