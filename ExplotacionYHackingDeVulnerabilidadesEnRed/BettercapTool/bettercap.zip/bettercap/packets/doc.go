// Package packets contains structure declarations for network packets and the main packets queue.
package packets
