#!/usr/bin/env python2
__version__ = '20110227'

if __name__ == '__main__': print __version__
