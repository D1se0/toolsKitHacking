﻿namespace FOCA.Database.Entities
{
    public class HttpMapTypesFiles
    {
        public int Id { get; set; }

        public int IdHttMap { get; set; }

        public int IdType { get; set; }

        public string Value { get; set; }

    }
}
