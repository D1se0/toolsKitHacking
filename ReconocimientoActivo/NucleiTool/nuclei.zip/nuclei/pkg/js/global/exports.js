exports = {
  // General
  dump_json: dump_json,
  to_json: to_json,
  to_array: to_array,
  hex_to_ascii: hex_to_ascii,

  // Active Directory
  getDomainControllerName: getDomainControllerName,
};
