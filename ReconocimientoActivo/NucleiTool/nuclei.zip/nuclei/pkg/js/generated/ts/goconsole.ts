

/**
 * NewGoConsolePrinter Function
 */
export function NewGoConsolePrinter(): GoConsolePrinter {
    return new GoConsolePrinter();
}



/**
 */
export class GoConsolePrinter {
    

    // Constructor of GoConsolePrinter
    constructor() {}
    /**
    * Log Method
    */
    public Log(msg: string): void {
        return;
    }
    

    /**
    * Warn Method
    */
    public Warn(msg: string): void {
        return;
    }
    

    /**
    * Error Method
    */
    public Error(msg: string): void {
        return;
    }
    

}

