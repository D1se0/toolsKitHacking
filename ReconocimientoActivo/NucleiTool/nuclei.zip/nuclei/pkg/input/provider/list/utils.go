package list

type ipOptions struct {
	ScanAllIPs bool
	IPV4       bool
	IPV6       bool
}
